﻿# include <iostream>

template <typename T>
struct S
{
    struct Subtype {};
    template <typename U>
    void f() {}

};

template <typename T>
void g()
{
    S<T> s;
    //  s.f<T>(); // Error
    s.template f<T>();
}

template <typename T>
void g(const T& t)
{
    //    T::Subtype* p; // Error! Идентификатор p не найден 
    typename T::Subtype* p;
}


int main()
{
    g<int>();
    g(S<int>{});
}
